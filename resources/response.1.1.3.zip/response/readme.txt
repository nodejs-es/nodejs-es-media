Response is a Free Premium Starter WordPress theme designed by CyberChimps.com in California.

Theme Homepage -  http://cyberchimps.com/response

Licensed under GNU General Public License v2.0 - http://www.gnu.org/licenses/gpl-2.0.html
-------------------------------------------------------------------------------------------------

For updated documentation, walkthroughs, and support please visit http://cyberchimps.com/

For updated docs please visit http://cyberchimps.com/response/docs/

For the support forum please visit: http://cyberchimps.com/forum/

For more support options please visit http://cyberchimps.com/support/


